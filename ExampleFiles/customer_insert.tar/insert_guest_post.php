<?php
$servername = "localhost";
$username = "wordpress";
$password = "wordpress123";
$dbname = "wordpress";

$firstname=$_POST["firstname"];
$lastname=$_POST["lastname"];
$email=$_POST["email"];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


$sql = "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('$firstname','$lastname','$email')";

echo "<html><title>Record Insert</title>";
echo "<body><table><tr><td><a href='new_guest_form.html'>New Guest<td><a href='query.php'>Query Data</tr></table>";


if ($conn->query($sql) === TRUE) {
  echo "New record " . $firstname . " " . $lastname . " created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
