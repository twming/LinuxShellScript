<?php
$servername = "localhost";
$username = "wordpress";
$password = "wordpress123";
$dbname = "wordpress";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, firstname, lastname, email FROM MyGuests";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  echo "<html><title>Guest Records</title>";
  echo "<body><table><tr><td><a href='new_guest_form.html'>New Guest<td><a href='query.php'>Query Data</tr></table><br>Here are the Guest Record(s)";

  echo "<table width=500 border=1>";
  echo "<tr><td>Id <td>First Name <td>Last Name <td>Email </tr>";
  
  while($row = $result->fetch_assoc()) {
    echo "<tr><td>" . $row["id"]. "<td>" . $row["firstname"]. "<td>" . $row["lastname"]. "<td>" . $row["email"]. "</tr>";
  }
} else {
  echo "<tr>0 results</tr>";
}
  echo "</table>";
  echo "</body></html>";
$conn->close();
?>